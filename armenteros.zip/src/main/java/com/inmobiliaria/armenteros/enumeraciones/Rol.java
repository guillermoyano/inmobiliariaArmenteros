package com.inmobiliaria.armenteros.enumeraciones;

/**
 *
 * @author Tonna/SA
 */
public enum Rol {
    ADMIN,
    USER
}

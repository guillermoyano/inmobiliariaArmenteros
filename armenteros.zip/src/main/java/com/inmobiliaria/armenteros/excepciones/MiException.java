package com.inmobiliaria.armenteros.excepciones;

/**
 *
 * @author Guillote
 */
public class MiException extends Exception{

    public MiException(String msg){
        super(msg);
    }
}

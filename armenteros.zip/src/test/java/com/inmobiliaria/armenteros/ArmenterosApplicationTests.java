package com.inmobiliaria.armenteros;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArmenterosApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.inmobiliaria.armenteros;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArmenterosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArmenterosApplication.class, args);
	}

}
